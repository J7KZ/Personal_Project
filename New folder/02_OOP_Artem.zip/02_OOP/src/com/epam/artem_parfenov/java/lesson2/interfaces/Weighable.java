package com.epam.artem_parfenov.java.lesson2.interfaces;

public interface Weighable {

	public double calculateRealWeight();
}