package com.epam.artem_parfenov.java.lesson2.productcolorenam;

public enum Color {

	RED, GREEN, YELLOW, PURPLE, WHITE;
}