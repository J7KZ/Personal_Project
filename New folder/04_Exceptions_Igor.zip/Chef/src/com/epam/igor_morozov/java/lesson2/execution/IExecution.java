package com.epam.igor_morozov.java.lesson2.execution;

public interface IExecution {

	void perform();
}
