package com.epam.igor_morozov.java.lesson2.data;

import com.epam.igor_morozov.java.lesson2.chef.storage.in.used.Container;

interface Data {

	void set();

	Container getBasket();

	Container getSausage();
}
