package com.epam.igor_morozov.java.lesson2.report.print;

public interface IPrint {

	public void print(String message);
}
