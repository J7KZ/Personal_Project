package com.epam.artem_parfenov.java.lesson5.interfaces;

public interface Weighable {

	public double calculateRealWeight();
}