package com.epam.artem_parfenov.java.lesson5.productcolorenam;

public enum Color {

	RED, GREEN, YELLOW, PURPLE, WHITE;
}