package com.epam.artem_parfenov.java.lesson4.productcolorenam;

public enum Color {

	RED, GREEN, YELLOW, PURPLE, WHITE;
}