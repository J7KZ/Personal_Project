package com.epam.artem_parfenov.java.lesson4.interfaces;

public interface Weighable {

	public double calculateRealWeight();
}