package com.epam.igor_morozov.java.lesson3.report.print;

public class Printer implements Printable {

	@Override
	public void print(String message) {
		System.out.println(message);

	}

}
