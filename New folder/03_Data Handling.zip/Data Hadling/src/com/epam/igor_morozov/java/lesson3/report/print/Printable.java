package com.epam.igor_morozov.java.lesson3.report.print;

public interface Printable {

	void print(String message);
}
