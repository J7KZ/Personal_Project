package com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class Salad extends Vegetables {

    public static final int SPECIFIC_CALORIES = 12;
    public final static String SALAD = "Salad";

    public Salad(double price, int weight, boolean dirty, boolean chop, boolean peel) {
	super(price, weight, dirty, chop, peel);
	this.setCurrentCalories(countCalories());
	this.setName(SALAD);
    }

    @Override
    public double countCalories() {
	return (SPECIFIC_CALORIES * (this.getWeight() / Ingredients.PERCENT));
    }

}
