package com.epam.Nikolay_Samokhin.java.lesson_2.sort;

import java.util.Comparator;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class SortPrice implements Comparator<Object> {

    @Override
    public int compare(Object price1, Object price2) {

	return (int) (((Ingredients) price1).getPrice() - ((Ingredients) price2).getPrice());
    }

}
