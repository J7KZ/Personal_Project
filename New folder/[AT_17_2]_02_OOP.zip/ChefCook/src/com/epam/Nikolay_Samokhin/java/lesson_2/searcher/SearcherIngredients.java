package com.epam.Nikolay_Samokhin.java.lesson_2.searcher;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;
import com.epam.Nikolay_Samokhin.java.lesson_2.storage.SaladBowl;

public class SearcherIngredients {
    public static final String NOT_FOUND = "Ingredients did not find in this range";
    private static final String ONE = "1";
    private static final String TWO = "2";
    private static final String THREE = "3";

    public static void searcher(SaladBowl masterSalad, double firstNumber, double secondNumber, String parametr) {
	switch (parametr) {
	case ONE:
	    searchPrice(masterSalad, firstNumber, secondNumber);
	    break;
	case TWO:
	    searchCalories(masterSalad, firstNumber, secondNumber);
	    break;
	case THREE:
	    searchWeight(masterSalad, firstNumber, secondNumber);
	    break;

	}

    }

    public static void searchPrice(SaladBowl bowl, double firstNumber, double secondNumber) {
	int counter = 0;
	for (Ingredients parametrs : bowl.getbowlOfVegetables()) {
	    if ((parametrs.getPrice() >= firstNumber) && (parametrs.getPrice() <= secondNumber)) {
		System.out.println(parametrs.getName());
		counter++;
	    }

	}
	if (counter == 0) {
	    System.out.println(NOT_FOUND);
	}
    }

    public static void searchCalories(SaladBowl bowl, double firstNumber, double secondNumber) {
	int counter = 0;
	for (Ingredients parametrs : bowl.getbowlOfVegetables()) {
	    if ((parametrs.getCurrentCalories() >= firstNumber) && (parametrs.getCurrentCalories() <= secondNumber)) {
		System.out.println(parametrs.getName());
		counter++;
	    }

	}
	if (counter == 0) {
	    System.out.println(NOT_FOUND);
	}
    }

    public static void searchWeight(SaladBowl bowl, double firstNumber, double secondNumber) {
	int counter = 0;
	for (Ingredients parametrs : bowl.getbowlOfVegetables()) {
	    if ((parametrs.getWeight() >= firstNumber) && (parametrs.getWeight() <= secondNumber)) {
		System.out.println(parametrs.getName());
		counter++;
	    }

	}
	if (counter == 0) {
	    System.out.println(NOT_FOUND);
	}
    }

}
