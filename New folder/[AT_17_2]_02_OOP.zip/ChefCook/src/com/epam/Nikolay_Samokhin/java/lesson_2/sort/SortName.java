package com.epam.Nikolay_Samokhin.java.lesson_2.sort;

import java.util.Comparator;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class SortName implements Comparator<Object> {

    @Override
    public int compare(Object name1, Object name2) {
	return ((Ingredients) name1).getName().compareTo(((Ingredients) name2).getName());

    }

}
