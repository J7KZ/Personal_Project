package com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.flavoring;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class SunFlowerOil extends Ingredients {

    public final static int SPECIFIC_CALORIES = 899;
    public final static String SUN_FLOWER_OIL = "SunFlowerOil";

    public SunFlowerOil(double price, int weight) {
	super(price, weight);
	this.setName(SUN_FLOWER_OIL);
	this.setCurrentCalories(countCalories());
    }

    @Override
    public double countCalories() {
	return (SPECIFIC_CALORIES * (this.getWeight() / Ingredients.PERCENT));
    }

}
