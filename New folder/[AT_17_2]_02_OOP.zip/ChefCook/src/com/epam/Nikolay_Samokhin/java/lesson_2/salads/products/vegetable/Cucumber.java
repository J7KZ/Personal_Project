package com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class Cucumber extends Vegetables {

    public static final int SPECIFIC_CALORIES = 15;
    public static final String CUCUMBER = "Cucumber";

    public Cucumber(double price, int weight, boolean dirty, boolean chop, boolean peel) {
	super(price, weight, dirty, chop, peel);
	this.setName(CUCUMBER);
	this.setCurrentCalories(countCalories());
    }

    @Override
    public double countCalories() {
	return ((SPECIFIC_CALORIES * this.getWeight()) / Ingredients.PERCENT);
    }

}
