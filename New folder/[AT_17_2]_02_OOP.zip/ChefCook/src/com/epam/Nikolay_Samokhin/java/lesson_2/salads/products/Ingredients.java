package com.epam.Nikolay_Samokhin.java.lesson_2.salads.products;

import com.epam.Nikolay_Samokhin.java.lesson_2.devices.CountCalories;

public abstract class Ingredients implements CountCalories {

    public static final int PERCENT = 100;
    private double price;
    private String name;
    private double weight;
    private Double currentCalories;

    public Ingredients(double price, double weight) {
	this.setPrice(price);
	this.setName(name);
	this.setWeight(weight);
	this.setCurrentCalories(currentCalories);
    }

    public double getPrice() {
	return price;
    }

    public void setPrice(double price) {
	this.price = price;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public double getWeight() {
	return weight;
    }

    public void setWeight(double weight) {
	this.weight = weight;

    }

    public Double getCurrentCalories() {
	return currentCalories;
    }

    public void setCurrentCalories(Double currentCalories) {
	this.currentCalories = currentCalories;
    }

    @Override
    public String toString() {
	return "\nIngredients name= " + name + " price " + price + " rub " + " weight " + weight + " gramm "
		+ " Caloiries " + currentCalories + " kcal";
    }
}
