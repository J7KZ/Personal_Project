package com.epam.Nikolay_Samokhin.java.lesson_2.devices;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public interface MakeFavoring {
    public Ingredients[] makeFavoring();
}
