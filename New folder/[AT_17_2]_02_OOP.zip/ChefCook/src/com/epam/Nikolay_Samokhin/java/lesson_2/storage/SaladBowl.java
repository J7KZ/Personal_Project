package com.epam.Nikolay_Samokhin.java.lesson_2.storage;

import java.util.Arrays;

import com.epam.Nikolay_Samokhin.java.lesson_2.devices.Mixable;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class SaladBowl implements Mixable {

    private Ingredients bowlOfVegetables[];
    private boolean mix = false;
    private int size;

    public SaladBowl(int size) {
	this.setSaladBowl(new Ingredients[size]);
	this.setMix(mix);
	this.setSize(size);

    }

    @Override
    public void mixSalads() {
	System.out.println("Salad was mixed");
	this.setMix(true);
    }

    public Ingredients[] getbowlOfVegetables() {
	return bowlOfVegetables;
    }

    public void setSaladBowl(Ingredients[] bowlOfVegetables) {
	this.bowlOfVegetables = bowlOfVegetables;

    }

    public int getSize() {
	return size;
    }

    public void setSize(int size) {
	this.size = size;
    }

    public boolean isMix() {
	return mix;
    }

    public void setMix(boolean mix) {
	this.mix = mix;
    }

    @Override
    public String toString() {
	return "Contains Salad  \n" + Arrays.toString(bowlOfVegetables) + "\n";
    }

}
