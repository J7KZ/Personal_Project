package com.epam.Nikolay_Samokhin.java.lesson_2;

import java.util.Scanner;

/**
 * Lesson_2 version_3_ChefCook created by Samokhin_Nikolay
 */

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.SaladWithOnion;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.SaladWithoutOnion;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;
import com.epam.Nikolay_Samokhin.java.lesson_2.searcher.SearcherIngredients;
import com.epam.Nikolay_Samokhin.java.lesson_2.sort.SortSalad;
import com.epam.Nikolay_Samokhin.java.lesson_2.storage.SaladBowl;

public class SaladMasterCheff {
    public final static String SEARCH_BY_PRICE = "\nIf you want to search by 'price', push button '1' and push 'Enter'";
    public final static String SEARCH_BY_WEIGHT = "If you want to search by 'weight', push button '2' and push 'Enter'";
    public final static String SEARCH_BY_CALORIES = "If you want to search by 'calories', push button '3' and push 'Enter'";
    public final static String SORT_BY_PRICE = "\nIf you want to sort by 'price', push button '1' and push 'Enter'";
    public final static String SORT_BY_WEIGHT = "If you want to sort by 'weight', push button '2' and push 'Enter'";
    public final static String SORT_BY_CALORIES = "If you want to sort by 'calories', push button '3' and push 'Enter'";
    public final static String SORT_BY_NAME = "If you want to sort by by 'name', push button '4' and push 'Enter'";
    public final static String ENTER_SEARCHE_RANGE = "\nEnter a search range where the first number is less than the second number";
    public final static String SALAD_WITH_ONION = "If you want salad with onion push button '1' and push 'Enter'";
    public final static String SALAD_WITHOUT_ONION = "If you want salad without onion push button '2' and push 'Enter'";
    public final static String NAME_SALAD_1 = "Salad with onion";
    public final static String NAME_SALAD_2 = "Salad without onion";
    public final static String ONE = "1";
    public final static String TWO = "2";
    public final static String THREE = "3";
    public final static String SHOW = "Show amount parametrs of Salad \nSalad Weight ";
    public final static String GRAMM = " gramm,";
    public final static String PRICE = " Price ";
    public final static String RUB = " rub,";
    public final static String CALORIES = " Calories ";
    public final static String KCAL = " kcal";
    
    SaladBowl masterSalad;
    Scanner inputValue = new Scanner(System.in);
    String parametr = null;
    int weight = 0;
    double calories = 0;
    double price = 0;
    double firstNumber, secondNumber;

    public static void main(String[] args) {

	SaladMasterCheff app = new SaladMasterCheff();
	app.startApp();
    }

    private void startApp() {
	CreatetSalad();
	getParametrsOftSalad();
	sortOfParametrs();
	searcherVegetables();

    }

    private void searcherVegetables() {
	System.out.println(SEARCH_BY_PRICE);
	System.out.println(SEARCH_BY_WEIGHT);
	System.out.println(SEARCH_BY_CALORIES);
	parametr = inputValue.next();
	System.out.println(ENTER_SEARCHE_RANGE);
	firstNumber = inputValue.nextDouble();
	secondNumber = inputValue.nextDouble();
	SearcherIngredients.searcher(masterSalad, firstNumber, secondNumber, parametr);
	inputValue.close();
    }

    private void sortOfParametrs() {
	System.out.println(SORT_BY_PRICE);
	System.out.println(SORT_BY_WEIGHT);
	System.out.println(SORT_BY_CALORIES);
	System.out.println(SORT_BY_NAME);
	parametr = inputValue.next();
	SortSalad.sortSalad(masterSalad, parametr);
	System.out.println(masterSalad);
    }

    private void CreatetSalad() {

	System.out.println(SALAD_WITH_ONION);
	System.out.println(SALAD_WITHOUT_ONION);
	parametr = inputValue.next();
	switch (parametr) {
	case ONE:
	    masterSalad = SourceSalad.getSalad(new SaladWithOnion(NAME_SALAD_1));
	    break;
	case TWO:
	    masterSalad = SourceSalad.getSalad(new SaladWithoutOnion(NAME_SALAD_2));
	    break;
	}
	System.out.println(masterSalad);

    }

    private void getParametrsOftSalad() {

	for (Ingredients parametrs : masterSalad.getbowlOfVegetables()) {
	    weight += parametrs.getWeight();
	    calories += parametrs.getCurrentCalories();
	    price += parametrs.getPrice();
	}

	System.out.println(SHOW + weight + GRAMM + PRICE + price + RUB + CALORIES + calories);
    }
}
