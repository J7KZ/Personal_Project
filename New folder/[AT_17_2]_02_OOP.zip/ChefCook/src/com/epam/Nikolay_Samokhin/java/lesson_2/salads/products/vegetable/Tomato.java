package com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class Tomato extends Vegetables {

    public static final int SPECIFIC_CALORIES = 20;
    public final static String TOMATO = "Tomato";

    public Tomato(double price, int weight, boolean dirty, boolean chop, boolean peel) {
	super(price, weight, dirty, chop, peel);
	this.setCurrentCalories(countCalories());
	this.setName(TOMATO);
    }

    @Override
    public double countCalories() {
	return (SPECIFIC_CALORIES * (this.getWeight() / Ingredients.PERCENT));
    }

}
