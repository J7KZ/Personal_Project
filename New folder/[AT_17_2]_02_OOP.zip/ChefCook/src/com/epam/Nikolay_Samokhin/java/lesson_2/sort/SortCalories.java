package com.epam.Nikolay_Samokhin.java.lesson_2.sort;

import java.util.Comparator;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class SortCalories implements Comparator<Object> {

    @Override
    public int compare(Object calories1, Object calories2) {
	return (int) (((Ingredients) calories1).getCurrentCalories() - ((Ingredients) calories2).getCurrentCalories());
    }

}
