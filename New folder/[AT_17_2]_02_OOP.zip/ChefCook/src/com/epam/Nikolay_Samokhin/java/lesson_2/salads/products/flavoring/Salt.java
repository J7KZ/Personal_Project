package com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.flavoring;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class Salt extends Ingredients {

    public static final int SPECIFIC_CALORIES = 0;
    public static final String SALT = "Salt";

    public Salt(double price, int weight) {
	super(price, weight);
	this.setName(SALT);
	this.setCurrentCalories(countCalories());
    }

    @Override
    public double countCalories() {
	return (SPECIFIC_CALORIES * (this.getWeight() / Ingredients.PERCENT));
    }

}
