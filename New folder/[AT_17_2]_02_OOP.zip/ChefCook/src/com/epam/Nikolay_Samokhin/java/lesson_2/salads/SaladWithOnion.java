package com.epam.Nikolay_Samokhin.java.lesson_2.salads;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.flavoring.Salt;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.flavoring.SunFlowerOil;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Cucumber;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Onion;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Salad;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Tomato;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Vegetables;

public class SaladWithOnion extends SaladRecept {
    public static final int AMOUNT_VEGETABLES = 4;
    public static final int AMOUNT_INGRIDIENTS = 2;

    public SaladWithOnion(String name) {
	super(name);

    }

    @Override
    public Vegetables[] makeVegetable() {

	Vegetables[] salad = new Vegetables[AMOUNT_VEGETABLES];
	{
	    salad[0] = new Onion(22.5, 100, true, true, true);
	    salad[1] = new Cucumber(42.5, 50, true, true, true);
	    salad[2] = new Salad(34, 100, true, true, false);
	    salad[3] = new Tomato(32.3, 22, true, false, false);

	}

	return salad;
    }

    @Override
    public Ingredients[] makeFavoring() {
	Ingredients[] flavorings = new Ingredients[AMOUNT_INGRIDIENTS];
	{
	    flavorings[0] = new Salt(2.71, 5);
	    flavorings[1] = new SunFlowerOil(21, 20);

	}
	return flavorings;
    }

}
