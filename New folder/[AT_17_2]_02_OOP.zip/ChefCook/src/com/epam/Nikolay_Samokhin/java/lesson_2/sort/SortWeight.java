package com.epam.Nikolay_Samokhin.java.lesson_2.sort;

import java.util.Comparator;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public class SortWeight implements Comparator<Object> {

    @Override
    public int compare(Object weight1, Object weight2) {

	return (int) (((Ingredients) weight1).getWeight() - ((Ingredients) weight2).getWeight());
    }

}
