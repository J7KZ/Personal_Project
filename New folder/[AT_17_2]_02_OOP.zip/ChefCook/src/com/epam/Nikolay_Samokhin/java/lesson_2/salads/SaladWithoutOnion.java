package com.epam.Nikolay_Samokhin.java.lesson_2.salads;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.flavoring.Salt;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.flavoring.SunFlowerOil;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Cucumber;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Onion;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Salad;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Tomato;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Vegetables;

public class SaladWithoutOnion extends SaladRecept {
    public static final int AMOUNT_VEGETABLES = 3;
    public static final int AMOUNT_INGRIDIENTS = 2;

    public SaladWithoutOnion(String name) {
	super(name);

    }

    @Override
    public Vegetables[] makeVegetable() {

	Vegetables[] salad = new Vegetables[AMOUNT_VEGETABLES];
	{
	    salad[0] = new Onion(2.4, 20, true, true, true);
	    salad[1] = new Cucumber(12, 100, true, false, true);
	    salad[2] = new Salad(154, 10, true, true, false);
	    salad[3] = new Tomato(2, 50, true, true, false);

	}

	return salad;
    }

    @Override
    public Ingredients[] makeFavoring() {

	Ingredients[] flavorings = new Ingredients[AMOUNT_INGRIDIENTS];
	{
	    flavorings[0] = new Salt(23, 32);
	    flavorings[1] = new SunFlowerOil(77, 23);

	}
	return flavorings;
    }

}
