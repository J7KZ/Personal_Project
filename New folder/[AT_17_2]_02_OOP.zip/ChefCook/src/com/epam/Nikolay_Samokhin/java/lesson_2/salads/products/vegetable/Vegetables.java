package com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable;

import com.epam.Nikolay_Samokhin.java.lesson_2.devices.Chopable;
import com.epam.Nikolay_Samokhin.java.lesson_2.devices.Peelable;
import com.epam.Nikolay_Samokhin.java.lesson_2.devices.WashVegetable;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;

public abstract class Vegetables extends Ingredients implements WashVegetable, Peelable, Chopable {

    private boolean dirty;
    private boolean chop;
    private boolean peel;
    public final static String CHOPED = " was choped";
    public final static String WASHED = " was washed";
    public final static String PEELED = " was peeled";

    public Vegetables(double price, int weight, boolean dirty, boolean chop, boolean peel) {
	super(price, weight);

	this.setDirty(dirty);
	this.setChop(chop);
	this.setPeel(peel);

    }

    @Override
    public void chopVegetable() {
	System.out.println(getName() + CHOPED);
	this.setChop(true);
    }

    @Override
    public void washVegetable() {
	System.out.println(getName() + WASHED);
	this.setDirty(false);
    }

    @Override
    public void peelVegetable() {
	System.out.println(getName() + PEELED);
	this.setPeel(false);
    }

    public boolean isDirty() {
	return dirty;
    }

    public void setDirty(boolean dirty) {
	this.dirty = dirty;
    }

    public boolean isChop() {
	return chop;
    }

    public void setChop(boolean chop) {
	this.chop = chop;
    }

    public boolean isPeel() {
	return peel;
    }

    public void setPeel(boolean peel) {
	this.peel = peel;
    }

}
