package com.epam.Nikolay_Samokhin.java.lesson_2.devices;

public interface Mixable {
    public void mixSalads();
}
