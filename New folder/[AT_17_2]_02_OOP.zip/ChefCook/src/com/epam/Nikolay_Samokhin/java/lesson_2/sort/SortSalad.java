package com.epam.Nikolay_Samokhin.java.lesson_2.sort;

import java.util.Arrays;

import com.epam.Nikolay_Samokhin.java.lesson_2.storage.SaladBowl;

public class SortSalad {
    private static final String ONE = "1";
    private static final String TWO = "2";
    private static final String THREE = "3";
    private static final String FOUR = "4";
    public static void sortSalad(SaladBowl salad, String parametr) {
	switch (parametr) {
	case ONE:
	    Arrays.sort(salad.getbowlOfVegetables(), new SortPrice());
	    break;
	case TWO:
	    Arrays.sort(salad.getbowlOfVegetables(), new SortWeight());
	    break;
	case THREE:
	    Arrays.sort(salad.getbowlOfVegetables(), new SortCalories());
	    break;
	case FOUR:
	    Arrays.sort(salad.getbowlOfVegetables(), new SortName());
	    break;
	}

    }
}
