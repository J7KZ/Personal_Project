package com.epam.Nikolay_Samokhin.java.lesson_2;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.SaladRecept;
import com.epam.Nikolay_Samokhin.java.lesson_2.storage.SaladBowl;

public class SourceSalad {

    public static SaladBowl getSalad(SaladRecept salad) {
	Service.ServiceVegetable.processVegetable(salad.getVegetables());
	SaladBowl bowl = Service.putInBowl(salad.getVegetables(), salad.makeFavoring());
	return bowl;
    }
}
