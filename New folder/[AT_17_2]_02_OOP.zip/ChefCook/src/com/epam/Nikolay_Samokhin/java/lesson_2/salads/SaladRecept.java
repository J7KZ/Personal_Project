package com.epam.Nikolay_Samokhin.java.lesson_2.salads;

import com.epam.Nikolay_Samokhin.java.lesson_2.devices.MakeFavoring;
import com.epam.Nikolay_Samokhin.java.lesson_2.devices.MakeVegetable;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Vegetables;

public abstract class SaladRecept implements MakeVegetable, MakeFavoring {

    private String name;
    private Ingredients[] flavoring;
    private Vegetables[] vegetables;

    public SaladRecept(String name) {
	this.setName(name);
	vegetables = makeVegetable();
	flavoring = makeFavoring();
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public Ingredients[] getFlavoring() {
	return flavoring;
    }

    public void setFlavoring(Ingredients[] flavoring) {
	this.flavoring = flavoring;
    }

    public Vegetables[] getVegetables() {
	return vegetables;
    }

}
