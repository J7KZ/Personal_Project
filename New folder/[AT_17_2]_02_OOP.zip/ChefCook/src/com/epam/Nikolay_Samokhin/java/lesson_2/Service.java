package com.epam.Nikolay_Samokhin.java.lesson_2;

import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.Ingredients;
import com.epam.Nikolay_Samokhin.java.lesson_2.salads.products.vegetable.Vegetables;
import com.epam.Nikolay_Samokhin.java.lesson_2.storage.SaladBowl;

public class Service {

    public static final boolean MIXED = true;
    public final static String CHECK_CONDITION = "Check condition and process vegetables\n";

    public static SaladBowl putInBowl(Vegetables[] cleaningVegetables, Ingredients[] flavoring) {

	SaladBowl saladBowl = new SaladBowl(cleaningVegetables.length + flavoring.length);
	{

	    for (int i = 0; i < saladBowl.getbowlOfVegetables().length; i++) {// Ingredients are added to the salad bowl
		if (i < cleaningVegetables.length) {
		    saladBowl.getbowlOfVegetables()[i] = cleaningVegetables[i];
		} else if (i >= cleaningVegetables.length) {
		    saladBowl.getbowlOfVegetables()[i] = flavoring[i - cleaningVegetables.length];
		}
	    }
	}

	if (saladBowl.isMix() != MIXED) {// Ingredients are mixed in the salad bowl
	    saladBowl.mixSalads();
	}

	return saladBowl;
    }

    public static class ServiceVegetable {
	public static final boolean DIRTY_VEGETABLE = true;
	public static final boolean NO_PEEL = true;
	public static final boolean NO_CHOP = true;

	public static void processVegetable(Vegetables[] vegetables) {

	    System.out.println(CHECK_CONDITION);
	    for (int i = 0; i < vegetables.length; i++) {
		if (vegetables[i].isDirty() == DIRTY_VEGETABLE) {
		    vegetables[i].washVegetable();
		}
		if ((vegetables[i].isPeel() == NO_PEEL)) {
		    vegetables[i].peelVegetable();
		}
		if ((vegetables[i].isChop() == NO_CHOP)) {
		    vegetables[i].chopVegetable();
		}
	    }
	}

    }

}
