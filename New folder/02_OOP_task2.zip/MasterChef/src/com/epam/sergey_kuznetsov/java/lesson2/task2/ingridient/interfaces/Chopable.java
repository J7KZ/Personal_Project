package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.interfaces;

public interface Chopable {
	static final String CHOPPED = "| Is chopped: ";
	public void chop();
}
