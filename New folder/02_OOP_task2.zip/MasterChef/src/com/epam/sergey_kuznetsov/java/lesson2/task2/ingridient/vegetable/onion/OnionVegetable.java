package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.onion;

import com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.Vegetable;

abstract class OnionVegetable extends Vegetable {
	public OnionVegetable() {
		setCategory(this);
	}
}
