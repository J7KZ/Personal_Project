package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.interfaces;

public interface Boilable {
	static final String BOILED = "| Is Boiled: ";
	public void boil();
}
