package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.fruit;

import com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.Vegetable;

abstract class FruitVegetable extends Vegetable {
	public FruitVegetable() {
		setCategory(this);
	}
}
