package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.tuberous;

import com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.Vegetable;

abstract class TuberousVegetable extends Vegetable {
	public TuberousVegetable() {
		setCategory(this);
	}
}
