package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.interfaces;

public interface Washable {
	static final String WASHED = "| Is washed: ";
	public void wash();
}
