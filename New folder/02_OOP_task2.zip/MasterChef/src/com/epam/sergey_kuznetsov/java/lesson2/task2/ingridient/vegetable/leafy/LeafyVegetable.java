package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.leafy;

import com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.Vegetable;

abstract class LeafyVegetable extends Vegetable {
	public LeafyVegetable() {
		setCategory(this);
	}
}
