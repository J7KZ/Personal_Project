package com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.cabbage;

import com.epam.sergey_kuznetsov.java.lesson2.task2.ingridient.vegetable.Vegetable;

abstract class CabbageVegetable extends Vegetable {

	public CabbageVegetable() {
		setCategory(this);
	}

}
