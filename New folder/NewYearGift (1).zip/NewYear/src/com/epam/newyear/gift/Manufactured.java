package com.epam.newyear.gift;

public interface Manufactured {
    void manufacture();
    double getWeight();
}
