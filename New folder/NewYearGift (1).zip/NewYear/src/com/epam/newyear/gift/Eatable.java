package com.epam.newyear.gift;

public interface Eatable {
    void eat();
    double getEnergy();
}
