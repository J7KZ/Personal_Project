package com.epam.alexey_bolshakov.java.jdbc.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connecting {

    private static Connection connection = null;

    public static Connection getConnection() {
	String url = "jdbc:mysql://localhost/book_storage?serverTimezone=Europe/Moscow&useSSL=false";
	String name = "root";
	String password = "123456789";
	try {
	    if (connection == null) {
		DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		connection = DriverManager.getConnection(url, name, password);
		System.out.println("Connection completed.\n");
	    }
	} catch (SQLException e) {
	    System.out.println("Connection failed.");
	    e.printStackTrace();
	}
	return connection;
    }

    public static void closeConnection() {
	try {
	    if (connection != null) {
		connection.close();
		System.out.println("\nConnection is closed");
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }
}