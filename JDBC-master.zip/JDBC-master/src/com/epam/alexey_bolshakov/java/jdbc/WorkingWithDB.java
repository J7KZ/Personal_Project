package com.epam.alexey_bolshakov.java.jdbc;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.epam.alexey_bolshakov.java.jdbc.connect.Connecting;
import com.epam.alexey_bolshakov.java.jdbc.logic.QueriesHandling;

public class WorkingWithDB {
    public static void main(String[] args) {

	QueriesHandling.getAllAuthors();
	splitter();

	QueriesHandling.getBooksOfAuthor("булгаков");
	splitter();
	QueriesHandling.getBooksOfAuthor("достоевский");
	splitter();
	QueriesHandling.getBooksOfAuthor("толстой");
	splitter();

	LocalDate date = LocalDate.of(2019, 01, 28);
	QueriesHandling.getProfitForDate(date);
	splitter();

	LocalDateTime dateTime = LocalDateTime.of(2020, 10, 10, 20, 20);
	QueriesHandling.addSoldBook("белая гвардия", dateTime);
	splitter();

	QueriesHandling.addSoldBookViaProcedure("собачье сердце");
	splitter();

	QueriesHandling.increaseAuthorBooksPrice("роулинг");
	splitter();

	QueriesHandling.getBooksOfAuthorBonusTask("булгаков");
	splitter();
	QueriesHandling.getBooksOfAuthorBonusTask("достоевский");
	splitter();
	QueriesHandling.getBooksOfAuthorBonusTask("толстой");
	splitter();

	QueriesHandling.increaseAuthorBooksPriceBonusTask("роулинг");
	splitter();

	Connecting.closeConnection();
    }

    private static void splitter() {
	System.out.println("\n---------------------------------------------");
    }
}