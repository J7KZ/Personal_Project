package com.epam.alexey_bolshakov.java.jdbc.logic;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.epam.alexey_bolshakov.java.jdbc.connect.Connecting;

public class QueriesHandling {
    private static Connection connection = Connecting.getConnection();
    private static ResultSet resultSet = null;

    public static void getAllAuthors() {
	System.out.println("TASK_1");

	String sql = "SELECT* FROM author";
	try (Statement statement = connection.createStatement()) {
	    resultSet = statement.executeQuery(sql);
	    System.out.println("\nSent query: \n" + sql + "\n");
	    System.out.println("Result:");

	    while (resultSet.next()) {
		StringBuilder fullName = new StringBuilder(resultSet.getString("first_name"));
		if (resultSet.getString("middle_name") != null) {
		    fullName.append(" ");
		    fullName.append(resultSet.getString("middle_name"));
		}
		fullName.append(" ");
		fullName.append(resultSet.getString("last_name"));
		System.out.println(fullName.toString());
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public static void getBooksOfAuthor(String authorLastName) {
	System.out.println("TASK_2");

	boolean authorExists = false;

	String sql = "SELECT* FROM author WHERE last_name = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    prepStatement.setString(1, authorLastName);
	    resultSet = prepStatement.executeQuery();
	    authorExists = resultSet.last();
	} catch (SQLException e) {
	    e.printStackTrace();
	}

	sql = "SELECT book_name\r\n" + "FROM book, author\r\n"
		+ "WHERE book.author_id = author.author_id AND last_name = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    if (authorExists) {
		System.out.printf("\nSent query: \n%s (%s).\n\n", sql, authorLastName);
		prepStatement.setString(1, authorLastName);
		resultSet = prepStatement.executeQuery();

		if (resultSet.last()) {
		    System.out.println("Result:");
		    resultSet.absolute(0);
		    while (resultSet.next()) {
			System.out.println(resultSet.getString(1));
		    }
		} else {
		    System.out.println("There're no books written by " + authorLastName + " in the shop.");
		}
	    } else {
		System.out.println("\nThere's no an author with the last name " + authorLastName + " in the shop.");
	    }

	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public static void getProfitForDate(LocalDate saleDate) {
	System.out.println("TASK_3");

	String sql = "SELECT SUM(price)\r\n" + "FROM book_sale\r\n" + "JOIN book ON book_sale.book_id=book.book_id \r\n"
		+ "WHERE CAST(date_time AS DATE) = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    prepStatement.setString(1, saleDate.toString());
	    resultSet = prepStatement.executeQuery();

	    System.out.printf("\nSent query: \n%s (%s).\n\n", sql, saleDate);
	    System.out.println("Result:");
	    resultSet.first();
	    System.out.println(resultSet.getInt(1));
	    System.out.printf("\nProfit for %s: %d\n", saleDate.toString(), resultSet.getInt(1));
	} catch (SQLException e) {
	    e.printStackTrace();
	}

    }

    public static void addSoldBook(String bookName, LocalDateTime saleDateTime) {
	System.out.println("TASK_4");

	boolean bookExists = false;
	int bookID = -1;

	String sql = "SELECT book_id \r\nFROM book \r\nWHERE book_name = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    prepStatement.setString(1, bookName);
	    resultSet = prepStatement.executeQuery();
	    System.out.printf("\nSent query: \n%s (%s).\n\n", sql, bookName);
	    bookExists = resultSet.last();
	    if (bookExists) {
		resultSet.absolute(1);
		bookID = resultSet.getInt(1);
		System.out.printf("Result: %d\n", bookID);
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}

	sql = "INSERT INTO book_sale (book_id, date_time) VALUES (?,?)";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    if (bookExists) {

		prepStatement.setInt(1, bookID);
		prepStatement.setString(2, saleDateTime.toString());
		prepStatement.executeUpdate();
		System.out.printf("\nSent query: \n%s (%s, %s).\n\n", sql, bookID, saleDateTime);
		System.out.println("The record of the sale has been added.");
	    } else {
		System.out.println("There's no such book in the store.");
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public static void addSoldBookViaProcedure(String bookName) {
	System.out.println("TASK_5");

	boolean bookExists = false;
	int bookID = -1;

	String sql = "SELECT book_id \r\nFROM book \r\nWHERE book_name = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    prepStatement.setString(1, bookName);
	    resultSet = prepStatement.executeQuery();
	    System.out.printf("\nSent query: \n%s (%s).\n\n", sql, bookName);
	    bookExists = resultSet.last();
	    if (bookExists) {
		resultSet.absolute(1);
		bookID = resultSet.getInt(1);
		System.out.printf("Result: %d\n", bookID);
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}

	String calling = "{call add_book_sale(?)}";
	try (CallableStatement prepStatement = connection.prepareCall(calling)) {
	    if (bookExists) {
		prepStatement.setInt(1, bookID);
		prepStatement.executeUpdate();
		System.out.printf("\nSent calling: \n%s (%s).\n\n", calling, bookID);
		System.out.println("The record of the sale has been added via add_book_sale procedure.");
	    } else {
		System.out.println("There's no such book in the store.");
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public static void increaseAuthorBooksPrice(String authorLastName) {
	System.out.println("TASK_6");

	boolean authorExists = false;
	int authorID = -1;

	String sql = "SELECT author_id \nFROM author WHERE last_name = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    prepStatement.setString(1, authorLastName);
	    resultSet = prepStatement.executeQuery();
	    System.out.printf("\nSent query: \n%s (%s).\n\n", sql, authorLastName);
	    authorExists = resultSet.first();
	    if (authorExists) {
		authorID = resultSet.getInt(1);
		System.out.println("Result: " + authorID);
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}

	sql = "UPDATE book SET price = price + 0.1 * price \nWHERE author_id = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    if (authorExists) {
		prepStatement.setInt(1, authorID);
		int numberOfBooks = prepStatement.executeUpdate();
		if (numberOfBooks != 0) {
		    System.out.printf("\nSent query: \n%s (%d).\n", sql, authorID);
		    System.out.printf("\nThe prices for %d books written by %s were increased by 10%%.\n",
			    numberOfBooks, authorLastName);
		} else {
		    System.out.println("\nThere're no books written by this author in the shop.\n");
		}
	    } else {
		System.out.println("There's no an an author with such last name in the shop.\n");
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public static void getBooksOfAuthorBonusTask(String authorLastName) {
	System.out.println("TASK_7");
	String sql = "SELECT COUNT(*)\r\n" + "FROM author\r\n" + "WHERE last_name = ?\r\n" + "UNION\r\n"
		+ "SELECT book_name\r\n" + "FROM book, author\r\n" + "WHERE book.author_id=author.author_id \r\n"
		+ "AND last_name=?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql)) {
	    prepStatement.setString(1, authorLastName);
	    prepStatement.setString(2, authorLastName);
	    resultSet = prepStatement.executeQuery();
	    System.out.printf("\nSent query: \n%s (%s).\n\n", sql, authorLastName);

	    resultSet.absolute(1);
	    int numberOfAuthors = resultSet.getInt(1);
	    if (numberOfAuthors > 0) {
		if (resultSet.next()) {
		    resultSet.absolute(1);
		    System.out.println("Result:");
		    while (resultSet.next()) {
			System.out.println(resultSet.getString(1));
		    }
		} else {
		    System.out.println("There're no books written by " + authorLastName + " in the shop.");
		}
	    } else {
		System.out.println("There's no an author with the last name " + authorLastName + " in the shop.");
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public static void increaseAuthorBooksPriceBonusTask(String authorLastName) {
	System.out.println("TASK_8");

	String sql = "SELECT book_id,price\r\n" + "FROM book INNER JOIN author \r\n"
		+ "ON book.author_id=author.author_id\r\n" + "WHERE last_name = ?";
	try (PreparedStatement prepStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE,
		ResultSet.CONCUR_UPDATABLE)) {
	    prepStatement.setString(1, authorLastName);
	    resultSet = prepStatement.executeQuery();

	    int numberOfBooks = 0;
	    while (resultSet.next()) {
		resultSet.updateDouble(2, resultSet.getInt(2) * 1.1);
		resultSet.updateRow();
		numberOfBooks++;
	    }

	    System.out.printf("\nSent query: \n%s (%s).\n\n", sql, authorLastName);
	    if (numberOfBooks != 0) {
		System.out.println("\nThe prices for " + numberOfBooks + " books written by " + authorLastName
			+ " were increased by 10%.");
	    } else {
		System.out.println("There're no books written by " + authorLastName + " in the shop.");
	    }
	} catch (SQLException e) {
	    e.printStackTrace();
	}
    }
}
