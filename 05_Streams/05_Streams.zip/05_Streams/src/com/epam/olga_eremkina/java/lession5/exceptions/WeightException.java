/**
 * 
 */
package com.epam.olga_eremkina.java.lession5.exceptions;

/**
 * @author Olga_Eremkina
 *
 */
public class WeightException extends Exception {

    private static final long serialVersionUID = 1L;

    public WeightException(String message) {
	super(message);
    }

}
