/**
 * 
 */
package com.epam.olga_eremkina.java.lession5.ingridientsnamesenum;

/**
 * @author Olga_Eremkina
 *
 */
public enum Names {
FRESH_CUCUMBER, SALTY_CUCUMBER, CANNED_GREEN_PEAS, BOILED_POTATO, BOILED_CARROT, BOILED_BEET, 
ONION, SOUR_CABBAGE, SUNFLOWER_OIL, SALT
}
